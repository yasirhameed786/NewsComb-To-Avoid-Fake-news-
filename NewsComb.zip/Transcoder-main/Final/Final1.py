from flask import Flask, send_file
from googletrans import Translator
from gtts import gTTS
import os
import requests
from moviepy.editor import ImageSequenceClip, AudioFileClip, concatenate_videoclips
import sys

VALID_LANGUAGES = ['tamil', 'english', 'french', 'spanish']
NEWS_API_KEY = '7669976854b84625a2be766571dd28ef'

def fetch_news(keyword, date):
    base_url = "https://newsapi.org/v2/everything"
    parameters = {
        "apiKey": NEWS_API_KEY,
        "q": keyword,
        "from": f"{date}T00:00:00",
        "to": f"{date}T23:59:59",
        "sortBy": "publishedAt",
        "language": "en",  
        "pageSize": 5,  
    }

    response = requests.get(base_url, params=parameters)

    if response.status_code == 200:
        news_data = response.json()
        articles = news_data.get("articles", [])
        return articles
    else:
        print(f"Error: {response.status_code}")
        return None

def translate_text(text, target_language):
    translator = Translator()

    if target_language.lower() in VALID_LANGUAGES:
        translation = translator.translate(text, dest=target_language.lower())
        return translation.text
    else:
        raise ValueError('Invalid destination language')

def text_to_audio(text, output_file):
    tts = gTTS(text=text, lang='en', slow=False)
    tts.save(output_file)
    return output_file

def download_images(query, count=5):
    access_key = '1UUKe0JTEhggSbrszMmv4pctWRge77iHQ_ihUD3xoI4'
    base_url = 'https://api.unsplash.com/photos/random'

    headers = {'Authorization': f'Client-ID {access_key}'}

    params = {
        'query': query,
        'count': count,
    }

    try:
        response = requests.get(base_url, headers=headers, params=params)
        data = response.json()

        os.makedirs('images1', exist_ok=True)

        for idx, item in enumerate(data):
            image_url = item['urls']['regular']
            image = requests.get(image_url)

            with open(f'images1/image_{idx + 1}.jpg', 'wb') as f:
                f.write(image.content)

    except Exception as e:
        print(f'Error: {e}')

def main(keyword, date, target_languages_input):
    target_languages = [lang.strip() for lang in target_languages_input.split(',')]

    audio_files = []

    for lang in target_languages:
        try:
            news_articles = fetch_news(keyword, date)

            if not news_articles:
                print("No news articles found.")
                return

            news_paragraph = " ".join([article['title'][:100] for article in news_articles])

            translated_text = translate_text(news_paragraph, lang)
            output_file = f"output_audio_{lang}.mp3"
            audio_files.append(text_to_audio(translated_text, output_file))
        except ValueError as e:
            print(f"Error: {e}")

    search_query = keyword.split()[0]
    download_images(search_query, count=20)

    images_path = "images1"
    output_video_path = r"output_video.mp4"

    image_files = [f for f in os.listdir(images_path) if f.endswith('.jpg')]

    image_files.sort()

    total_audio_duration = sum(AudioFileClip(audio_file).duration for audio_file in audio_files)

    fps = len(image_files) / total_audio_duration

    clips = [ImageSequenceClip([os.path.join(images_path, image_file)], fps=fps) for image_file in image_files]

    video_clip = concatenate_videoclips(clips, method="compose")

    for lang, audio_file in zip(target_languages, audio_files):
        lang_audio_clip = AudioFileClip(audio_file)
        video_clip = video_clip.set_audio(lang_audio_clip)

    video_clip.write_videofile(output_video_path, codec='mpeg4', audio_codec='mp3', fps=fps)

    video_clip.close()  # Close the video file

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
