import os
import requests

def get_news(api_key, date, keyword, language='en', num_articles=5):
    base_url = "https://newsapi.org/v2/everything"
    parameters = {
        "apiKey": api_key,
        "q": keyword,
        "from": f"{date}T00:00:00",
        "to": f"{date}T23:59:59",
        "sortBy": "publishedAt",
        "language": language,
        "pageSize": num_articles,
    }

    response = requests.get(base_url, params=parameters)

    if response.status_code == 200:
        news_data = response.json()
        articles = news_data.get("articles", [])
        return articles
    else:
        print(f"Error: {response.status_code}")
        return None

def save_news_to_file(news, filepath='saved_news.txt'):
    with open(filepath, 'a') as file:
        file.write("\n".join([article['title'] for article in news]))
        file.write("\n")

# Replace 'YOUR_API_KEY' with your actual News API key
api_key = '7669976854b84625a2be766571dd28ef'

# Specify the absolute path where you want to save the file
save_path = os.path.abspath(r'C:\Users\vikne\Desktop\Transcoder\as\news.txt')

# Get input from the user
date_to_fetch = input("Enter the date (YYYY-MM-DD): ")
keyword_to_search = input("Enter a keyword for news search: ")

news_articles = get_news(api_key, date_to_fetch, keyword_to_search)

if news_articles:
    print(f"Top news for {date_to_fetch} related to '{keyword_to_search}' in English:")
    news_paragraph = "\n".join([f"{i}. {article['title']}" for i, article in enumerate(news_articles, start=1)])
    print(news_paragraph)

    # Save the news to an absolute path
    save_news_to_file(news_articles, filepath=save_path)

    print(f"News saved to '{save_path}'")
else:
    print("Failed to retrieve news.")
