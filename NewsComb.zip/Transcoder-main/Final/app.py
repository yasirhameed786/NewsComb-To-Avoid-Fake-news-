from flask import Flask, render_template, request, jsonify, send_file
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run_script', methods=['POST'])
def run_script():
    try:
        data = request.json
        news_input = data.get('news', '')
        date_input = data.get('date', '')
        languages_input = data.get('languages', '')

        command = f'python final1.py "{news_input}" "{date_input}" "{languages_input}"'
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = process.communicate()

        if process.returncode == 0:
            return jsonify({'status': 'success', 'message': 'Script is running in the background.'}), 200
        else:
            return jsonify({'status': 'error', 'message': f'Script failed with error: {err.decode("utf-8")}'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/download_video')
def download_video():
    video_path = 'output_video.mp4'
    return send_file(video_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
